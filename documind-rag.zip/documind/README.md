# DocuMind — RAG Document Q&A Assistant with Eval Harness

Ask questions over your own documents and get answers grounded in retrieved
passages, with citations — or an explicit "I don't know" when the documents
don't contain the answer.

The point of this project is not the chat box. It's that the retrieval quality
is **measured**: there's an eval harness that scores the pipeline over a
labelled question set, so changing the chunk size or the prompt produces a
number rather than a vibe.

## Architecture

```
data/*.pdf
    │
    ▼  ingest.py        chunking (800 chars, 150 overlap, sentence-aware)
 Chunk[]  ──────────▶   retriever.py   all-MiniLM-L6-v2 embeddings
    │                                   L2-normalised → FAISS IndexFlatIP
    ▼
question ──▶ top-k cosine search ──▶ filter by min_score ──▶ pipeline.py
                                                                │
                                        no passages clear the bar → abstain
                                                                │
                                        else → grounded prompt → Claude → answer + [n] citations
```

Two separate abstention mechanisms, deliberately:

1. **Retrieval-level** — if no chunk clears `min_score` cosine similarity, the
   LLM is never called. Cheap, and it stops the model being handed junk context
   and asked to be helpful anyway.
2. **Generation-level** — the system prompt instructs the model to return a
   fixed abstention string when the passages are insufficient.

## Setup

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...     # or copy .env.example to .env
```

## Use

```bash
# put your PDFs / notes in ./data, then:
python build_index.py --data data --out .index --chunk-size 800 --overlap 150

streamlit run app.py        # UI: upload, tune chunk size / top-k / min score, ask
```

## Eval

Fill `evals/questions.json` with cases against your own documents. Three kinds:

| field | meaning |
|---|---|
| `expected_answer` | the fact the system should return (LLM-judged, wording-agnostic) |
| `expected_source` | file the answer lives in — used for retrieval hit-rate |
| `unanswerable: true` | the system **must** abstain on this one |

Aim for ~20 cases, with 4–6 unanswerable. The unanswerable cases are the ones
that catch hallucination; without them a system that confidently makes things up
scores well.

```bash
python -m evals.run_eval --index .index --questions evals/questions.json --top-k 4
```

Output:

```
=== DocuMind eval ===
           n_cases: 20
retrieval_hit_rate: 0.900
answer_correctness: 0.812
abstention_accuracy: 0.833
```

Failing cases are printed with the expected answer, what came back, and which
sources were retrieved — so you can tell a retrieval failure (wrong chunks) from
a generation failure (right chunks, bad answer).

### Suggested experiments

Run the eval before and after each change and record the numbers:

- chunk size 400 vs 800 vs 1500 — smaller chunks usually raise hit-rate and hurt
  answer completeness
- top-k 2 vs 4 vs 8 — more context is not monotonically better
- `min_score` 0.0 vs 0.2 vs 0.35 — trades abstention accuracy against coverage

A table of those results in your README is the single most interview-useful
artifact here.

## Layout

```
documind/ingest.py      loading + sentence-aware chunking with overlap
documind/retriever.py   embeddings, FAISS index, save/load
documind/pipeline.py    grounded prompt, abstention, citations
evals/run_eval.py       hit-rate / correctness / abstention scoring
build_index.py          CLI index builder
app.py                  Streamlit UI
```
