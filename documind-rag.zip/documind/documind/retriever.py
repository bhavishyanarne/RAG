"""Embedding + FAISS vector index with save/load.

Embeddings are L2-normalised and the index uses inner product, which makes
the returned score a cosine similarity in [-1, 1].
"""

from __future__ import annotations

import json
import os

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

from .ingest import Chunk

DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


class Retriever:
    def __init__(self, model_name: str = DEFAULT_MODEL):
        self.model_name = model_name
        self.model = SentenceTransformer(model_name)
        self.index: faiss.Index | None = None
        self.chunks: list[Chunk] = []

    # ---------- build ----------

    def _embed(self, texts: list[str]) -> np.ndarray:
        vecs = self.model.encode(
            texts,
            batch_size=32,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        return vecs.astype("float32")

    def build(self, chunks: list[Chunk]) -> "Retriever":
        if not chunks:
            raise ValueError("no chunks to index — is the data folder empty?")
        self.chunks = chunks
        vecs = self._embed([c.text for c in chunks])
        self.index = faiss.IndexFlatIP(vecs.shape[1])
        self.index.add(vecs)
        return self

    # ---------- query ----------

    def search(self, query: str, k: int = 4) -> list[tuple[Chunk, float]]:
        if self.index is None:
            raise RuntimeError("index not built — call build() or load() first")
        k = min(k, len(self.chunks))
        qvec = self._embed([query])
        scores, idxs = self.index.search(qvec, k)
        return [
            (self.chunks[i], float(s))
            for i, s in zip(idxs[0], scores[0])
            if i != -1
        ]

    # ---------- persistence ----------

    def save(self, path: str) -> None:
        os.makedirs(path, exist_ok=True)
        faiss.write_index(self.index, os.path.join(path, "index.faiss"))
        with open(os.path.join(path, "chunks.json"), "w", encoding="utf-8") as fh:
            json.dump(
                {
                    "model_name": self.model_name,
                    "chunks": [c.to_dict() for c in self.chunks],
                },
                fh,
            )

    @classmethod
    def load(cls, path: str) -> "Retriever":
        with open(os.path.join(path, "chunks.json"), encoding="utf-8") as fh:
            payload = json.load(fh)
        retriever = cls(payload["model_name"])
        retriever.chunks = [Chunk(**c) for c in payload["chunks"]]
        retriever.index = faiss.read_index(os.path.join(path, "index.faiss"))
        return retriever
