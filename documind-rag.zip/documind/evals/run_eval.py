"""Eval harness for the DocuMind RAG pipeline.

Scores three things over a labelled question set:

  retrieval_hit_rate  - did the expected chunk's source document appear in top-k?
  answer_correctness  - does the answer contain the expected facts? (LLM-judged)
  abstention_accuracy - did it abstain exactly on the unanswerable questions?

Run:  python -m evals.run_eval --index .index --questions evals/questions.json
"""

from __future__ import annotations

import argparse
import json
import os
import statistics
import sys
from dataclasses import dataclass

import anthropic

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from documind.pipeline import RAGPipeline  # noqa: E402
from documind.retriever import Retriever  # noqa: E402

JUDGE_MODEL = "claude-sonnet-4-6"

JUDGE_PROMPT = """You are grading a question-answering system.

Question: {question}
Expected answer: {expected}
System answer: {actual}

Does the system answer convey the expected answer? Ignore wording, ordering,
extra citations and extra detail that does not contradict the expected answer.

Reply with exactly one word: CORRECT or INCORRECT."""


@dataclass
class Case:
    question: str
    expected_answer: str | None = None
    expected_source: str | None = None
    unanswerable: bool = False


@dataclass
class Result:
    case: Case
    answer_text: str
    retrieved_sources: list[str]
    retrieval_hit: bool | None
    correct: bool | None
    abstained: bool


def load_cases(path: str) -> list[Case]:
    with open(path, encoding="utf-8") as fh:
        return [Case(**row) for row in json.load(fh)]


def judge(client: anthropic.Anthropic, case: Case, actual: str) -> bool:
    response = client.messages.create(
        model=JUDGE_MODEL,
        max_tokens=10,
        messages=[
            {
                "role": "user",
                "content": JUDGE_PROMPT.format(
                    question=case.question,
                    expected=case.expected_answer,
                    actual=actual,
                ),
            }
        ],
    )
    verdict = "".join(b.text for b in response.content if b.type == "text")
    return verdict.strip().upper().startswith("CORRECT")


def run(index_path: str, questions_path: str, top_k: int) -> list[Result]:
    retriever = Retriever.load(index_path)
    pipeline = RAGPipeline(retriever, top_k=top_k)
    client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

    results: list[Result] = []
    for case in load_cases(questions_path):
        answer = pipeline.ask(case.question)
        sources = [c.source for c in answer.sources]

        retrieval_hit = (
            case.expected_source in sources if case.expected_source else None
        )
        correct = (
            None
            if case.unanswerable or not case.expected_answer
            else judge(client, case, answer.text)
        )

        results.append(
            Result(
                case=case,
                answer_text=answer.text,
                retrieved_sources=sources,
                retrieval_hit=retrieval_hit,
                correct=correct,
                abstained=answer.abstained,
            )
        )
    return results


def report(results: list[Result]) -> dict:
    hits = [r.retrieval_hit for r in results if r.retrieval_hit is not None]
    graded = [r.correct for r in results if r.correct is not None]
    abstention = [
        r.abstained == r.case.unanswerable
        for r in results
        if r.case.unanswerable or r.case.expected_answer
    ]

    def rate(values: list[bool]) -> float:
        return round(statistics.mean(values), 3) if values else float("nan")

    metrics = {
        "n_cases": len(results),
        "retrieval_hit_rate": rate(hits),
        "answer_correctness": rate(graded),
        "abstention_accuracy": rate(abstention),
    }

    print("\n=== DocuMind eval ===")
    for key, value in metrics.items():
        print(f"{key:>20}: {value}")

    failures = [
        r
        for r in results
        if r.correct is False or (r.abstained != r.case.unanswerable)
    ]
    if failures:
        print(f"\n--- {len(failures)} failing case(s) ---")
        for r in failures:
            print(f"\nQ: {r.case.question}")
            print(f"  expected : {r.case.expected_answer or '(abstain)'}")
            print(f"  got      : {r.answer_text[:160]}")
            print(f"  retrieved: {r.retrieved_sources}")

    return metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", default=".index")
    parser.add_argument("--questions", default="evals/questions.json")
    parser.add_argument("--top-k", type=int, default=4)
    parser.add_argument("--out", default=None, help="write metrics JSON here")
    args = parser.parse_args()

    results = run(args.index, args.questions, args.top_k)
    metrics = report(results)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(metrics, fh, indent=2)


if __name__ == "__main__":
    main()
