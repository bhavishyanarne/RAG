"""The RAG pipeline: retrieve -> ground -> answer (or abstain)."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

import anthropic

from .ingest import Chunk
from .retriever import Retriever

MODEL = "claude-sonnet-4-6"
ABSTAIN = "I don't know based on the provided documents."

SYSTEM_PROMPT = f"""You answer questions using ONLY the numbered context passages given to you.

Rules:
1. If the passages do not contain enough information to answer, reply with exactly:
   {ABSTAIN}
   Do not guess, and do not fall back on general knowledge.
2. When you can answer, keep it concise and factual.
3. Cite the passages you used with bracketed numbers, e.g. [1] or [2][3].
   Every factual sentence must carry at least one citation.
4. Never invent a citation number that is not in the context."""


@dataclass
class Answer:
    question: str
    text: str
    sources: list[Chunk] = field(default_factory=list)
    scores: list[float] = field(default_factory=list)

    @property
    def abstained(self) -> bool:
        return ABSTAIN.rstrip(".").lower() in self.text.rstrip(".").lower()


def format_context(hits: list[tuple[Chunk, float]]) -> str:
    blocks = []
    for n, (chunk, _score) in enumerate(hits, start=1):
        loc = f"{chunk.source}" + (f", page {chunk.page}" if chunk.page else "")
        blocks.append(f"[{n}] (source: {loc})\n{chunk.text}")
    return "\n\n".join(blocks)


class RAGPipeline:
    def __init__(
        self,
        retriever: Retriever,
        client: anthropic.Anthropic | None = None,
        top_k: int = 4,
        min_score: float = 0.20,
    ):
        self.retriever = retriever
        self.client = client or anthropic.Anthropic(
            api_key=os.environ.get("ANTHROPIC_API_KEY")
        )
        self.top_k = top_k
        # Below this cosine similarity the retrieval is treated as a miss, so
        # the model is never handed irrelevant context and asked to be useful.
        self.min_score = min_score

    def ask(self, question: str, top_k: int | None = None) -> Answer:
        k = top_k or self.top_k
        hits = self.retriever.search(question, k=k)
        hits = [(c, s) for c, s in hits if s >= self.min_score]

        if not hits:
            return Answer(question=question, text=ABSTAIN)

        response = self.client.messages.create(
            model=MODEL,
            max_tokens=700,
            system=SYSTEM_PROMPT,
            messages=[
                {
                    "role": "user",
                    "content": (
                        f"Context passages:\n\n{format_context(hits)}\n\n"
                        f"Question: {question}"
                    ),
                }
            ],
        )
        text = "".join(b.text for b in response.content if b.type == "text").strip()

        return Answer(
            question=question,
            text=text,
            sources=[c for c, _ in hits],
            scores=[s for _, s in hits],
        )
