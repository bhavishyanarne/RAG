"""Build the FAISS index from ./data.

Usage:
    python build_index.py --data data --out .index --chunk-size 800 --overlap 150
"""

from __future__ import annotations

import argparse

from documind.ingest import load_chunks
from documind.retriever import Retriever


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data")
    parser.add_argument("--out", default=".index")
    parser.add_argument("--chunk-size", type=int, default=800)
    parser.add_argument("--overlap", type=int, default=150)
    args = parser.parse_args()

    chunks = load_chunks(args.data, args.chunk_size, args.overlap)
    print(f"loaded {len(chunks)} chunks from {args.data}")

    retriever = Retriever().build(chunks)
    retriever.save(args.out)
    print(f"index written to {args.out}")


if __name__ == "__main__":
    main()
