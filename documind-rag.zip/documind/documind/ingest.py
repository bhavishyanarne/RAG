"""Document loading and chunking.

Turns a folder of PDFs / .txt / .md files into overlapping text chunks,
each carrying enough metadata to cite it back to the user.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, asdict
from typing import Iterable

from pypdf import PdfReader

SUPPORTED = (".pdf", ".txt", ".md")


@dataclass
class Chunk:
    chunk_id: str
    source: str        # file name
    page: int | None   # page number for PDFs, None otherwise
    text: str

    def to_dict(self) -> dict:
        return asdict(self)


def _clean(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _read_pdf(path: str) -> list[tuple[int, str]]:
    reader = PdfReader(path)
    pages = []
    for i, page in enumerate(reader.pages, start=1):
        text = _clean(page.extract_text() or "")
        if text:
            pages.append((i, text))
    return pages


def _read_plain(path: str) -> list[tuple[int | None, str]]:
    with open(path, "r", encoding="utf-8", errors="ignore") as fh:
        text = _clean(fh.read())
    return [(None, text)] if text else []


def split_text(text: str, chunk_size: int = 800, overlap: int = 150) -> list[str]:
    """Split on sentence-ish boundaries, packing up to chunk_size chars per chunk.

    Overlap carries the tail of one chunk into the next so an answer that
    straddles a boundary is still retrievable.
    """
    if overlap >= chunk_size:
        raise ValueError("overlap must be smaller than chunk_size")

    sentences = re.split(r"(?<=[.!?])\s+|\n\n+", text)
    sentences = [s.strip() for s in sentences if s.strip()]

    chunks: list[str] = []
    current = ""
    for sentence in sentences:
        # A single oversized sentence gets hard-split rather than dropped.
        while len(sentence) > chunk_size:
            if current:
                chunks.append(current)
                current = ""
            chunks.append(sentence[:chunk_size])
            sentence = sentence[chunk_size - overlap:]

        if len(current) + len(sentence) + 1 <= chunk_size:
            current = f"{current} {sentence}".strip()
        else:
            if current:
                chunks.append(current)
            current = sentence

    if current:
        chunks.append(current)

    if overlap and len(chunks) > 1:
        overlapped = [chunks[0]]
        for prev, nxt in zip(chunks, chunks[1:]):
            overlapped.append((prev[-overlap:] + " " + nxt).strip())
        chunks = overlapped

    return chunks


def load_chunks(
    folder: str, chunk_size: int = 800, overlap: int = 150
) -> list[Chunk]:
    """Read every supported file in `folder` and return chunks."""
    chunks: list[Chunk] = []
    for fname in sorted(os.listdir(folder)):
        if not fname.lower().endswith(SUPPORTED):
            continue
        path = os.path.join(folder, fname)
        units: Iterable[tuple[int | None, str]]
        units = _read_pdf(path) if fname.lower().endswith(".pdf") else _read_plain(path)

        for page, text in units:
            for i, piece in enumerate(split_text(text, chunk_size, overlap)):
                page_tag = f"p{page}" if page else "p0"
                chunks.append(
                    Chunk(
                        chunk_id=f"{fname}::{page_tag}::{i}",
                        source=fname,
                        page=page,
                        text=piece,
                    )
                )
    return chunks
