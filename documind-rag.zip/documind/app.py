"""Streamlit front end for DocuMind.

Run:  streamlit run app.py
"""

from __future__ import annotations

import os
import tempfile

import streamlit as st

from documind.ingest import load_chunks
from documind.pipeline import RAGPipeline
from documind.retriever import Retriever

st.set_page_config(page_title="DocuMind — RAG Document Q&A", layout="wide")
st.title("DocuMind")
st.caption("Ask questions over your own documents. Answers are grounded in retrieved passages, with citations.")

with st.sidebar:
    st.header("Retrieval settings")
    chunk_size = st.slider("Chunk size (chars)", 300, 2000, 800, step=100)
    overlap = st.slider("Chunk overlap (chars)", 0, 400, 150, step=25)
    top_k = st.slider("Top-k passages", 1, 10, 4)
    min_score = st.slider("Min similarity", 0.0, 0.6, 0.20, step=0.05)
    st.caption("Raising min similarity makes the system abstain more often instead of answering from weak matches.")

uploads = st.file_uploader(
    "Upload PDFs, .txt or .md files",
    type=["pdf", "txt", "md"],
    accept_multiple_files=True,
)

if uploads and st.button("Build index", type="primary"):
    with st.spinner("Chunking and embedding…"):
        tmpdir = tempfile.mkdtemp()
        for f in uploads:
            with open(os.path.join(tmpdir, f.name), "wb") as out:
                out.write(f.getbuffer())

        chunks = load_chunks(tmpdir, chunk_size, overlap)
        st.session_state.retriever = Retriever().build(chunks)
        st.session_state.n_chunks = len(chunks)
    st.success(f"Indexed {st.session_state.n_chunks} chunks from {len(uploads)} file(s).")

if "retriever" in st.session_state:
    question = st.text_input("Question", placeholder="What does the document say about…")

    if question:
        pipeline = RAGPipeline(
            st.session_state.retriever, top_k=top_k, min_score=min_score
        )
        with st.spinner("Retrieving and answering…"):
            answer = pipeline.ask(question)

        if answer.abstained:
            st.warning(answer.text)
        else:
            st.markdown(answer.text)

        if answer.sources:
            st.subheader("Retrieved passages")
            for n, (chunk, score) in enumerate(
                zip(answer.sources, answer.scores), start=1
            ):
                loc = chunk.source + (f", page {chunk.page}" if chunk.page else "")
                with st.expander(f"[{n}] {loc}  ·  similarity {score:.3f}"):
                    st.write(chunk.text)
else:
    st.info("Upload one or more documents and build the index to start asking questions.")
